/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Project/Maven2/JavaApp/src/main/java/${packagePath}/${mainClassName}.java to edit this template
 */

package com.mycompany.tarefa2;

import java.util.Scanner;

/**
 *
 * @author Windows 10
 */
public class Tarefa2 {
	
 public static void main(String args[]){

  Scanner entrada = new Scanner(System.in);

  System.out.print("Numero? ");
  int numero = entrada.nextInt();

  System.out.println("O numero lido foi [" + numero + "]");

 }
}
   
        
  
